 <!-- Vendor JS Files -->
 <script src="{{ asset('frontend/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
 <script src="{{ asset('frontend/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>
 <script src="{{ asset('frontend/assets/vendor/glightbox/js/glightbox.min.js') }}"></script>
 <script src="{{ asset('frontend/assets/vendor/aos/aos.js') }}"></script>
 <script src="{{ asset('frontend/assets/vendor/php-email-form/validate.js') }}"></script>

 <!-- Template Main JS File -->
 <script src="{{ asset('frontend/assets/js/main.js') }}"></script>

 {{-- font awesome --}}
 <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/js/all.min.js"
     integrity="sha512-u3fPA7V8qQmhBPNT5quvaXVa1mnnLSXUep5PS1qo5NRzHwG19aHmNJnj1Q8hpA/nBWZtZD4r4AX6YOt5ynLN2g=="
     crossorigin="anonymous" referrerpolicy="no-referrer"></script>
