<footer id="footer" class="footer">

    {{-- <div class="footer-content">
      <div class="container">

        <div class="row g-5">
          <div class="col-lg-4">
            <h3 class="footer-heading">About ZenBlog</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam ab, perspiciatis beatae autem deleniti voluptate nulla a dolores, exercitationem eveniet libero laudantium recusandae officiis qui aliquid blanditiis omnis quae. Explicabo?</p>
            <p><a href="about.html" class="footer-link-more">Learn More</a></p>
          </div>
          <div class="col-6 col-lg-2">
            <h3 class="footer-heading">Navigation</h3>
            <ul class="footer-links list-unstyled">
              <li><a href="index.html"><i class="bi bi-chevron-right"></i> Home</a></li>
              <li><a href="index.html"><i class="bi bi-chevron-right"></i> Blog</a></li>
              <li><a href="category.html"><i class="bi bi-chevron-right"></i> Categories</a></li>
              <li><a href="single-post.html"><i class="bi bi-chevron-right"></i> Single Post</a></li>
              <li><a href="about.html"><i class="bi bi-chevron-right"></i> About us</a></li>
              <li><a href="contact.html"><i class="bi bi-chevron-right"></i> Contact</a></li>
            </ul>
          </div>
          <div class="col-6 col-lg-2">
            <h3 class="footer-heading">Categories</h3>
            <ul class="footer-links list-unstyled">
              <li><a href="category.html"><i class="bi bi-chevron-right"></i> Business</a></li>
              <li><a href="category.html"><i class="bi bi-chevron-right"></i> Culture</a></li>
              <li><a href="category.html"><i class="bi bi-chevron-right"></i> Sport</a></li>
              <li><a href="category.html"><i class="bi bi-chevron-right"></i> Food</a></li>
              <li><a href="category.html"><i class="bi bi-chevron-right"></i> Politics</a></li>
              <li><a href="category.html"><i class="bi bi-chevron-right"></i> Celebrity</a></li>
              <li><a href="category.html"><i class="bi bi-chevron-right"></i> Startups</a></li>
              <li><a href="category.html"><i class="bi bi-chevron-right"></i> Travel</a></li>

            </ul>
          </div>

          <div class="col-lg-4">
            <h3 class="footer-heading">Recent Posts</h3>

            <ul class="footer-links footer-blog-entry list-unstyled">
              <li>
                <a href="single-post.html" class="d-flex align-items-center">
                  <img src="{{asset('frontend/assets/img/post-sq-1.jpg')}}" alt="" class="img-fluid me-3">
                  <div>
                    <div class="post-meta d-block"><span class="date">Culture</span> <span class="mx-1">&bullet;</span> <span>Jul 5th '22</span></div>
                    <span>5 Great Startup Tips for Female Founders</span>
                  </div>
                </a>
              </li>

              <li>
                <a href="single-post.html" class="d-flex align-items-center">
                  <img src="{{asset('frontend/assets/img/post-sq-2.jpg')}}" alt="" class="img-fluid me-3">
                  <div>
                    <div class="post-meta d-block"><span class="date">Culture</span> <span class="mx-1">&bullet;</span> <span>Jul 5th '22</span></div>
                    <span>What is the son of Football Coach John Gruden, Deuce Gruden doing Now?</span>
                  </div>
                </a>
              </li>

              <li>
                <a href="single-post.html" class="d-flex align-items-center">
                  <img src="{{asset('frontend/assets/img/post-sq-3.jpg')}}" alt="" class="img-fluid me-3">
                  <div>
                    <div class="post-meta d-block"><span class="date">Culture</span> <span class="mx-1">&bullet;</span> <span>Jul 5th '22</span></div>
                    <span>Life Insurance And Pregnancy: A Working Mom’s Guide</span>
                  </div>
                </a>
              </li>

              <li>
                <a href="single-post.html" class="d-flex align-items-center">
                  <img src="{{asset('frontend/assets/img/post-sq-4.jpg')}}" alt="" class="img-fluid me-3">
                  <div>
                    <div class="post-meta d-block"><span class="date">Culture</span> <span class="mx-1">&bullet;</span> <span>Jul 5th '22</span></div>
                    <span>How to Avoid Distraction and Stay Focused During Video Calls?</span>
                  </div>
                </a>
              </li>

            </ul>

          </div>
        </div>
      </div>
    </div> --}}

    <div class="footer-legal">
      <div class="container text-dark">

        <div class="row justify-content-between">
            <div class="col-4 col-md-3 text-center text-md-start mb-3 mb-md-0">
              <div class="container m-2 my-2">
                <h6>Payment Method</h6>
                <i class="fa-solid fa-building-columns fa-2xl"></i>
              </div>
            </div>
            <div class="col-4 col-md-3 text-center text-md-start mb-3 mb-md-0">
              <div class="container m-2 my-2">
                <h6>Responsible Gaming</h6>
                <i class="fa-solid fa-dice fa-2xl"></i>
                <i class="fa-solid fa-chess-knight fa-2xl"></i>
              </div>
            </div>
            <div class="col-4 col-md-3 text-center text-md-start mb-3 mb-md-0">
              <div class="container m-2 my-2">
                <h6>Cirtifications</h6>
                <img src="{{ asset('assets/logo-gc.png') }}" width="100px" alt="">
              </div>
            </div>

            <div class="col-md-3 text-dark">
              <div class="social-links mb-3 mb-lg-0 text-center text-md-end">
                <a href="#" class="twitter text-dark"><i class="bi bi-twitter"></i></a>
                <a href="#" class="facebook text-dark"><i class="bi bi-facebook"></i></a>
                <a href="#" class="instagram text-dark"><i class="bi bi-instagram"></i></a>
                <a href="#" class="google-plus text-dark"><i class="bi bi-skype"></i></a>
                <a href="#" class="linkedin text-dark"><i class="bi bi-linkedin"></i></a>
              </div>

            </div>

          </div>

        <hr>

        <div class="row justify-content-between">
          <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
            <div class="copyright">
              © Copyright <strong><span>Us</span></strong>. All Rights Reserved
            </div>

          </div>

          <div class="col-md-6 text-center text-md-end mb-3 mb-md-0">
            <a href="" class="text-dark">Terms & Conditions</a>
            <a href="" class="mx-3 text-dark">About Us</a>

          </div>

        </div>

      </div>
    </div>

  </footer>
